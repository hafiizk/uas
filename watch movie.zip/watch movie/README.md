# Katalog-Movie

Fitur yang terdapat dalam aplikasi berikut:

1. Halaman untuk pencarian film.
2. Halaman detail ketika item hasil pencarian dipilih.
3. Tampilan poster dari film.

![Halaman Pencarian](https://github.com/wahyuirgan/Katalog-Movie/blob/master/screenshot/1.png)
![Pencarian](https://github.com/wahyuirgan/Katalog-Movie/blob/master/screenshot/2.png)
![Hasil Pencarian](https://github.com/wahyuirgan/Katalog-Movie/blob/master/screenshot/3.png)
![Halaman Detail](https://github.com/wahyuirgan/Katalog-Movie/blob/master/screenshot/4.png)
